import { useState, useRef, useCallback } from "react";
import mammoth from "mammoth";

// ─── Constants ────────────────────────────────────────────────────────────────
const GEMINI_MODEL = "gemini-1.5-flash";
const GEMINI_API = "/api/gemini";

const RATING_LABEL = (r) => {
  if (r >= 4.5) return "Excellent";
  if (r >= 3.5) return "Good";
  if (r >= 2.5) return "Average";
  return "Needs Improvement";
};

const RATING_COLOR = (r) => {
  if (r >= 4.5) return { bg: "#f0fdf4", border: "#86efac", text: "#166534" };
  if (r >= 3.5) return { bg: "#eff6ff", border: "#93c5fd", text: "#1d4ed8" };
  if (r >= 2.5) return { bg: "#fefce8", border: "#fde047", text: "#854d0e" };
  return { bg: "#fef2f2", border: "#fca5a5", text: "#991b1b" };
};

const STEPS = ["upload", "processing", "config", "generating", "done"];

const EXTRACT_PROMPT = `Extract key information from this teacher observation report. Return ONLY valid JSON — no markdown fences, no extra text. Use this exact schema:
{
  "teacher_name": "string",
  "date": "string (as written in document)",
  "class_section": "string",
  "subject": "string",
  "tt_ratio": 60,
  "st_ratio": 40,
  "strengths": ["short 6-8 word phrase","short 6-8 word phrase"],
  "improvements": ["short 6-8 word phrase","short 6-8 word phrase"],
  "action_points": ["short actionable phrase max 10 words","short actionable phrase max 10 words"],
  "aha_moment": "one crisp sentence max 15 words",
  "noteworthy": "one crisp sentence max 15 words",
  "lesson_flow": "one crisp sentence max 12 words",
  "resources": "comma-separated list only",
  "raw_summary": "max 2 sentences, 30 words total"
}
Rules: tt_ratio + st_ratio must sum to 100 and be numbers. All arrays must have exactly 1-2 short items. Never use long paragraphs — keep every field concise. Never return null, use "Not specified" for missing fields.`;

// ─── Helpers ──────────────────────────────────────────────────────────────────
async function readFileAsArrayBuffer(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(new Error("Read failed"));
    r.readAsArrayBuffer(file);
  });
}

async function readFileAsBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result.split(",")[1]);
    r.onerror = () => rej(new Error("Read failed"));
    r.readAsDataURL(file);
  });
}

// Extract text from DOCX using mammoth (browser-side, no API needed)
async function extractDocxText(file) {
  const arrayBuffer = await readFileAsArrayBuffer(file);
  const result = await mammoth.extractRawText({ arrayBuffer });
  if (!result.value || result.value.trim().length < 20) {
    throw new Error("DOCX appears empty or could not be read");
  }
  return result.value;
}

async function callGemini(messages, systemPrompt, maxTokens = 2000) {
  // Convert Anthropic message format to Gemini format
  const geminiContents = messages.map(m => {
    if (Array.isArray(m.content)) {
      const parts = m.content.map(c => {
        if (c.type === "text") return { text: c.text };
        if (c.type === "document") {
          return {
            inline_data: {
              mime_type: c.source.media_type,
              data: c.source.data
            }
          };
        }
        return { text: "" };
      });
      return { role: m.role === "assistant" ? "model" : "user", parts };
    }
    return { role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] };
  });

  const body = {
    system_instruction: systemPrompt ? { parts: [{ text: systemPrompt }] } : undefined,
    contents: geminiContents,
    generationConfig: {
      maxOutputTokens: maxTokens,
      temperature: 0.3,
    }
  };

  const res = await fetch(GEMINI_API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: GEMINI_MODEL, ...body }),
  });
  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`Gemini API error ${res.status}: ${errText.slice(0, 200)}`);
  }
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || "Gemini API error");
  return data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "";
}

// Alias so all existing code works unchanged
const callClaude = callGemini;

function safeParseJSON(raw) {
  // Strip markdown fences, BOM, leading/trailing whitespace
  let cleaned = raw.replace(/```json|```/gi, "").trim();
  // Find first { and last } to isolate JSON object
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start !== -1 && end !== -1) cleaned = cleaned.slice(start, end + 1);
  return JSON.parse(cleaned);
}

async function extractFromFile(file) {
  const isPdf = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
  const isDocx = file.name.toLowerCase().endsWith(".docx") || file.name.toLowerCase().endsWith(".doc");
  const isText = file.type.startsWith("text/") || file.name.toLowerCase().endsWith(".txt");

  let content;

  if (isPdf) {
    // PDFs are sent as base64 documents — supported natively by the API
    const b64 = await readFileAsBase64(file);
    content = [
      {
        type: "document",
        source: { type: "base64", media_type: "application/pdf", data: b64 },
      },
      { type: "text", text: EXTRACT_PROMPT },
    ];
  } else if (isDocx) {
    // DOCX: extract text with mammoth first, then send as plain text to API
    const text = await extractDocxText(file);
    content = [
      {
        type: "text",
        text: `${EXTRACT_PROMPT}\n\nDOCUMENT TEXT:\n${text.slice(0, 12000)}`,
      },
    ];
  } else if (isText) {
    const text = await file.text();
    content = [
      {
        type: "text",
        text: `${EXTRACT_PROMPT}\n\nDOCUMENT TEXT:\n${text.slice(0, 12000)}`,
      },
    ];
  } else {
    throw new Error(`Unsupported file type. Please upload PDF or DOCX files.`);
  }

  const raw = await callClaude(
    [{ role: "user", content }],
    "You are a precise data extractor. Return ONLY valid JSON — no markdown, no explanation, no preamble.",
    1500
  );

  const parsed = safeParseJSON(raw);

  // Sanitise — ensure required fields exist
  if (!parsed.teacher_name || parsed.teacher_name === "string") {
    throw new Error("Could not extract teacher name from document");
  }
  if (!Array.isArray(parsed.strengths)) parsed.strengths = ["Not specified"];
  if (!Array.isArray(parsed.improvements)) parsed.improvements = ["Not specified"];
  if (!Array.isArray(parsed.action_points)) parsed.action_points = ["Not specified"];
  parsed.tt_ratio = Number(parsed.tt_ratio) || 60;
  parsed.st_ratio = Number(parsed.st_ratio) || 40;

  return parsed;
}

const VALID_RATINGS = [4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0];

function snapRating(raw) {
  const n = parseFloat(raw);
  if (isNaN(n)) return 4.3;
  // Clamp to 4.1–5.0 then snap to nearest valid value
  const clamped = Math.min(5.0, Math.max(4.1, n));
  return VALID_RATINGS.reduce((prev, curr) =>
    Math.abs(curr - clamped) < Math.abs(prev - clamped) ? curr : prev
  );
}

async function rateTeacher(records, allTeacherNames = [], alreadyAssigned = []) {
  const summary = records.map(r =>
    `Date: ${r.date}
Strengths: ${r.strengths?.join(", ")}
Improvements: ${r.improvements?.join(", ")}
TT%: ${r.tt_ratio} | ST%: ${r.st_ratio}
AHA: ${r.aha_moment}
Noteworthy: ${r.noteworthy}
Lesson Flow: ${r.lesson_flow}
Summary: ${r.raw_summary}`
  ).join("\n\n---\n\n");

  const avoidStr = alreadyAssigned.length > 0
    ? `IMPORTANT: Ratings already assigned to other teachers this session: ${alreadyAssigned.join(", ")}. Pick a DIFFERENT value from the allowed list unless evidence strongly matches.`
    : "";

  const raw = await callClaude([{
    role: "user",
    content: `You are evaluating ${records[0].teacher_name} (${records[0].subject}, ${records[0].class_section}).
Analyse their ${records.length} observation report(s) carefully and return a JSON evaluation.

ALLOWED RATING VALUES — you MUST pick exactly one: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0
4.1 = lesson delivered but low engagement, little student talk, needs major improvement
4.2 = basic delivery, limited student interaction, needs more variety and depth  
4.3 = adequate teaching, some engagement, clear areas to develop
4.4 = meets expectations, decent engagement, moderate improvement areas
4.5 = solid delivery, noticeable strengths, some room to grow
4.6 = strong performance, good student interaction, minor gaps
4.7 = very strong, high engagement, effective questioning, small refinements needed
4.8 = excellent, creative strategies, strong outcomes, very minor gaps
4.9 = near-perfect, outstanding engagement and delivery
5.0 = masterclass: fully student-led, highly innovative, exceptional outcomes
${avoidStr}

Base your rating on: ST% (higher = better engagement), lesson creativity, critical thinking promoted, real-world connections, quality of feedback, pacing, outcomes achieved.

Return ONLY this JSON (no markdown):
{
  "rating": <one of the 10 allowed values above>,
  "consolidated_strengths": ["concise 6-8 word phrase","concise 6-8 word phrase"],
  "consolidated_improvements": ["concise 6-8 word phrase","concise 6-8 word phrase"],
  "consolidated_actions": ["actionable phrase max 10 words","actionable phrase max 10 words"],
  "aha_moment": "2-3 sentences describing the key learning moment, min 25 words",
  "noteworthy": "2-3 sentences highlighting what stood out, min 25 words",
  "lesson_flow": "one sentence describing lesson structure, max 12 words",
  "overall_summary": "2-3 sentences, admin-friendly, 40-70 words"
}

OBSERVATION DATA:
${summary}`
  }],
    "You are a school academic evaluator. You MUST choose rating from: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0 only. Return ONLY valid JSON.", 1400);

  const parsed = safeParseJSON(raw);
  // Code-level enforcement — no matter what AI returns, snap to valid range
  parsed.rating = snapRating(parsed.rating);
  return parsed;
}

async function generateExecutiveSummary(teachers, blockName, period, generatedBy) {
  const overview = teachers.map(t =>
    `${t.teacher_name} (${t.subject}): Rating ${t.analysis.rating}/5. Strengths: ${t.analysis.consolidated_strengths?.join(", ")}. Improvements: ${t.analysis.consolidated_improvements?.join(", ")}.`
  ).join("\n");

  const raw = await callClaude([{
    role: "user",
    content: `Write a 3-sentence executive summary for a school principal reviewing teacher performance for ${blockName}, period ${period}. Sentence 1: overall block performance snapshot. Sentence 2: key strengths observed across teachers. Sentence 3: main areas for development. Must be 40-60 words total, professional, specific, no generic filler.

TEACHER DATA:
${overview}

Return ONLY the paragraph. No labels, no JSON.`
  }], "You are a senior academic coordinator writing for busy school principals. Be specific and professional. Response must be 40-60 words.", 400);

  return raw.trim();
}

// ─── HTML Generator ────────────────────────────────────────────────────────────
function generateHTML(teachers, config, execSummary) {
  const avgRating = (teachers.reduce((s, t) => s + t.analysis.rating, 0) / teachers.length).toFixed(1);
  const rc = RATING_COLOR(parseFloat(avgRating));

  const starsHTML = (rating) => {
    const full = Math.floor(rating);
    const half = rating % 1 >= 0.25 && rating % 1 < 0.75;
    const stars = Array.from({ length: 5 }, (_, i) => {
      if (i < full) return `<span style="color:#f59e0b;font-size:16px;">★</span>`;
      if (i === full && half) return `<span style="color:#f59e0b;font-size:16px;">½</span>`;
      return `<span style="color:#d1d5db;font-size:16px;">★</span>`;
    }).join("");
    return `<span style="letter-spacing:2px;">${stars}</span> <span style="font-size:13px;font-weight:700;color:#92400e;margin-left:4px;">${rating}/5</span>`;
  };

  const overviewRows = teachers.map((t, i) => {
    const rc2 = RATING_COLOR(t.analysis.rating);
    const bg = i % 2 === 0 ? "#f8fafc" : "#ffffff";
    const dateStr = Array.isArray(t.records) && t.records.length > 1
      ? `${t.records[0].date} – ${t.records[t.records.length - 1].date}`
      : (t.records[0]?.date || "—");
    return `
    <tr style="background:${bg};">
      <td style="padding:10px 14px;font-weight:600;color:#1e3a5f;border:1px solid #d1d9e0;">${t.teacher_name}</td>
      <td style="padding:10px 14px;border:1px solid #d1d9e0;">${t.records[0]?.class_section || "—"}</td>
      <td style="padding:10px 14px;border:1px solid #d1d9e0;">${t.records[0]?.subject || "—"}</td>
      <td style="padding:10px 14px;text-align:center;border:1px solid #d1d9e0;">
        <div style="background:#dbeafe;color:#1e40af;padding:3px 10px;border-radius:20px;font-size:13px;font-weight:600;display:inline-block;">
          TT: ${t.avgTT}% | ST: ${t.avgST}%
        </div>
      </td>
      <td style="padding:10px 14px;text-align:center;border:1px solid #d1d9e0;">
        <div style="background:${rc2.bg};border:1px solid ${rc2.border};color:${rc2.text};padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700;display:inline-block;">
          ${t.analysis.rating}/5 &nbsp;${RATING_LABEL(t.analysis.rating)}
        </div>
      </td>
      <td style="padding:10px 14px;border:1px solid #d1d9e0;">${dateStr}</td>
    </tr>`;
  }).join("");

  const teacherCards = teachers.map((t) => {
    const rc2 = RATING_COLOR(t.analysis.rating);
    const dateStr = Array.isArray(t.records) && t.records.length > 1
      ? `${t.records[0].date} – ${t.records[t.records.length - 1].date} (${t.records.length} days)`
      : (t.records[0]?.date || "—");

    const glows = (t.analysis.consolidated_strengths || []).map(s =>
      `<li style="margin-bottom:6px;font-size:13px;color:#374151;line-height:1.5;">${s}</li>`).join("");
    const grows = (t.analysis.consolidated_improvements || []).map(s =>
      `<li style="margin-bottom:6px;font-size:13px;color:#374151;line-height:1.5;">${s}</li>`).join("");
    const actions = (t.analysis.consolidated_actions || []).map(s =>
      `<li style="margin-bottom:6px;font-size:13px;color:#374151;line-height:1.5;">${s}</li>`).join("");
    const resources = [...new Set(t.records.map(r => r.resources).filter(Boolean))].join("; ") || "Not specified";

    return `
    <div style="margin-bottom:40px;page-break-inside:avoid;">
      <div style="background:linear-gradient(135deg,#1e3a5f,#2563eb);color:white;padding:16px 22px;border-radius:10px 10px 0 0;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <div>
          <h3 style="margin:0;font-size:18px;font-weight:700;">${t.teacher_name}</h3>
          <p style="margin:4px 0 0;font-size:13px;opacity:0.85;">
            ${t.records[0]?.class_section || "—"} &nbsp;|&nbsp; ${t.records[0]?.subject || "—"} &nbsp;|&nbsp; ${dateStr}
          </p>
        </div>
        <div style="background:${rc2.bg};border:1px solid ${rc2.border};padding:8px 16px;border-radius:10px;text-align:center;">
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:${rc2.text};font-weight:600;">Rating</div>
          <div style="margin-top:4px;">${starsHTML(t.analysis.rating)}</div>
          <div style="font-size:11px;color:${rc2.text};font-weight:700;margin-top:2px;">${RATING_LABEL(t.analysis.rating)}</div>
        </div>
      </div>

      <div style="border:1px solid #d1d9e0;border-top:none;border-radius:0 0 10px 10px;overflow:hidden;">
        <div style="padding:16px 22px;background:#f0f7ff;border-bottom:1px solid #d1d9e0;">
          <p style="margin:0 0 8px;font-weight:600;font-size:13px;color:#374151;text-transform:uppercase;letter-spacing:0.5px;">Teacher : Student Talk Ratio</p>
          <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
            <div style="display:flex;align-items:center;gap:6px;">
              <div style="width:120px;height:10px;background:#e2e8f0;border-radius:5px;overflow:hidden;">
                <div style="width:${t.avgTT}%;height:100%;background:#2563eb;border-radius:5px;"></div>
              </div>
              <span style="font-size:13px;color:#1e3a5f;font-weight:600;">Teacher: ${t.avgTT}%</span>
            </div>
            <div style="display:flex;align-items:center;gap:6px;">
              <div style="width:120px;height:10px;background:#e2e8f0;border-radius:5px;overflow:hidden;">
                <div style="width:${t.avgST}%;height:100%;background:#059669;border-radius:5px;"></div>
              </div>
              <span style="font-size:13px;color:#065f46;font-weight:600;">Student: ${t.avgST}%</span>
            </div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;">
          <div style="padding:16px 22px;border-right:1px solid #d1d9e0;border-bottom:1px solid #d1d9e0;">
            <p style="margin:0 0 10px;font-weight:700;font-size:14px;color:#166534;">🌟 GLOWS (Strengths)</p>
            <ul style="margin:0;padding-left:18px;">${glows}</ul>
          </div>
          <div style="padding:16px 22px;border-bottom:1px solid #d1d9e0;">
            <p style="margin:0 0 10px;font-weight:700;font-size:14px;color:#92400e;">📈 GROWS (Areas for Improvement)</p>
            <ul style="margin:0;padding-left:18px;">${grows}</ul>
          </div>
        </div>

        <div style="padding:16px 22px;background:#fffbeb;border-bottom:1px solid #d1d9e0;">
          <p style="margin:0 0 10px;font-weight:700;font-size:14px;color:#92400e;">✅ Action Points (Next Steps)</p>
          <ul style="margin:0;padding-left:18px;">${actions}</ul>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0;">
          <div style="padding:14px 18px;border-right:1px solid #d1d9e0;">
            <p style="margin:0 0 6px;font-weight:700;font-size:13px;color:#6d28d9;">💡 AHA Moment</p>
            <p style="margin:0;font-size:12px;color:#374151;line-height:1.5;">${t.analysis.aha_moment || "Not specified"}</p>
          </div>
          <div style="padding:14px 18px;border-right:1px solid #d1d9e0;">
            <p style="margin:0 0 6px;font-weight:700;font-size:13px;color:#0369a1;">⭐ Noteworthy Practices</p>
            <p style="margin:0;font-size:12px;color:#374151;line-height:1.5;">${t.analysis.noteworthy || "Not specified"}</p>
          </div>
          <div style="padding:14px 18px;">
            <p style="margin:0 0 6px;font-weight:700;font-size:13px;color:#374151;">📋 Lesson Flow</p>
            <p style="margin:0;font-size:12px;color:#374151;line-height:1.5;">${t.analysis.lesson_flow || "Not specified"}</p>
          </div>
        </div>

        <div style="padding:14px 20px;background:#f8fafc;border-top:1px solid #d1d9e0;">
          <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:#374151;">📚 Resources Used</p>
          <p style="margin:0 0 10px;font-size:12px;color:#374151;">${resources}</p>
          <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:#374151;">📝 Overall Summary</p>
          <p style="margin:0;font-size:13px;color:#374151;line-height:1.6;font-style:italic;">${t.analysis.overall_summary || ""}</p>
        </div>
      </div>
    </div>`;
  }).join("");

  const overallRc = RATING_COLOR(parseFloat(avgRating));

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>Consolidated Teacher Performance Report — ${config.blockName}</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6f9; color: #222; margin: 0; padding: 0; }
    .page { max-width: 1100px; margin: 0 auto; background: white; }
    @media print { body { background: white; } .page { max-width: 100%; } }
    table { width: 100%; border-collapse: collapse; }
  </style>
</head>
<body>
<div class="page">

  <div style="background:linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%);color:white;padding:24px 40px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
    <div>
      <div style="margin:0 0 2px;font-size:21px;font-weight:800;line-height:1.2;letter-spacing:0.3px;">${config.schoolName}</div>
      <h1 style="margin:0;font-size:17px;font-weight:700;line-height:1.3;letter-spacing:-0.2px;opacity:0.9;">Consolidated Teacher Performance Report</h1>
      <div style="margin-top:6px;font-size:11px;opacity:0.5;">Generated by ${config.generatedBy} &nbsp;·&nbsp; Developed by Devnil Chatterjee</div>
    </div>
    <div style="display:flex;gap:24px;flex-wrap:wrap;">
      <div style="text-align:center;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;opacity:0.65;">Block</div>
        <div style="font-size:20px;font-weight:700;margin-top:2px;">${config.blockName}</div>
      </div>
      <div style="text-align:center;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;opacity:0.65;">Period</div>
        <div style="font-size:14px;font-weight:600;margin-top:2px;">${config.period}</div>
      </div>
      <div style="text-align:center;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;opacity:0.65;">Teachers</div>
        <div style="font-size:20px;font-weight:700;margin-top:2px;">${teachers.length}</div>
      </div>
    </div>
  </div>

  <div style="padding:36px 44px;">

    <div style="margin-bottom:36px;display:grid;grid-template-columns:1fr auto;gap:20px;align-items:start;">
      <div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
          <div style="width:4px;height:24px;background:#2563eb;border-radius:2px;"></div>
          <h2 style="margin:0;font-size:18px;font-weight:700;color:#1e3a5f;">Executive Summary</h2>
        </div>
        <div style="background:#f0f7ff;border:1px solid #bfdbfe;border-radius:10px;padding:18px 22px;">
          <p style="margin:0;font-size:14px;color:#374151;line-height:1.8;">${execSummary}</p>
        </div>
      </div>
      <div style="background:${overallRc.bg};border:2px solid ${overallRc.border};border-radius:12px;padding:20px 24px;text-align:center;min-width:160px;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:${overallRc.text};font-weight:700;margin-bottom:8px;">Overall Block Rating</div>
        <div style="font-size:36px;font-weight:900;color:${overallRc.text};line-height:1;">${avgRating}</div>
        <div style="font-size:13px;color:${overallRc.text};opacity:0.7;margin-bottom:8px;">out of 5</div>
        <div style="margin-top:8px;font-size:12px;font-weight:700;color:${overallRc.text};background:${overallRc.border}40;padding:3px 10px;border-radius:20px;">${RATING_LABEL(parseFloat(avgRating))}</div>
      </div>
    </div>

    <div style="margin-bottom:36px;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
        <div style="width:4px;height:24px;background:#2563eb;border-radius:2px;"></div>
        <h2 style="margin:0;font-size:18px;font-weight:700;color:#1e3a5f;">Teacher Overview</h2>
      </div>
      <div style="border-radius:10px;overflow:hidden;border:1px solid #d1d9e0;box-shadow:0 1px 4px rgba(0,0,0,0.06);">
        <table>
          <thead>
            <tr style="background:#1e3a5f;color:white;">
              <th style="padding:11px 14px;text-align:left;font-size:13px;font-weight:600;">Teacher Name</th>
              <th style="padding:11px 14px;text-align:left;font-size:13px;font-weight:600;">Class/Section</th>
              <th style="padding:11px 14px;text-align:left;font-size:13px;font-weight:600;">Subject(s)</th>
              <th style="padding:11px 14px;text-align:center;font-size:13px;font-weight:600;">Talk Ratio</th>
              <th style="padding:11px 14px;text-align:center;font-size:13px;font-weight:600;">Rating</th>
              <th style="padding:11px 14px;text-align:left;font-size:13px;font-weight:600;">Date(s)</th>
            </tr>
          </thead>
          <tbody>${overviewRows}</tbody>
        </table>
      </div>
    </div>

    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;">
      <div style="width:4px;height:24px;background:#2563eb;border-radius:2px;"></div>
      <h2 style="margin:0;font-size:18px;font-weight:700;color:#1e3a5f;">Individual Teacher Reports</h2>
    </div>

    ${teacherCards}

  </div>

  <!-- FOOTER -->
  <div style="margin-top:40px;padding:20px 44px;border-top:2px solid #e2e8f0;text-align:center;background:#f8fafc;">
    <div style="font-size:15px;font-weight:700;color:#1e3a5f;letter-spacing:0.3px;">Sunbeam School, Lahartara</div>
    <div style="font-size:12px;color:#6b7280;margin-top:4px;">© 2026 Devnil Chatterjee</div>
  </div>

</div>
</body>
</html>`;
}

// ─── UI Components ─────────────────────────────────────────────────────────────
function ProgressBar({ pct, color = "#2563eb" }) {
  return (
    <div style={{ background: "#e2e8f0", borderRadius: 8, height: 8, overflow: "hidden" }}>
      <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: 8, transition: "width 0.4s ease" }} />
    </div>
  );
}

function FileCard({ file, status, error }) {
  const icons = { pending: "⏳", processing: "⚙️", done: "✅", error: "❌" };
  const colors = { pending: "#6b7280", processing: "#2563eb", done: "#166534", error: "#991b1b" };
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", background: "#f8fafc", borderRadius: 8, border: "1px solid #e2e8f0", marginBottom: 6 }}>
      <span style={{ fontSize: 18 }}>{file.name.endsWith(".pdf") ? "📄" : "📝"}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: "#1e3a5f", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{file.name}</div>
        {error && <div style={{ fontSize: 11, color: "#991b1b" }}>{error}</div>}
      </div>
      <span style={{ fontSize: 16, color: colors[status] }}>{icons[status]}</span>
    </div>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [step, setStep] = useState("upload");
  const [files, setFiles] = useState([]);
  const [fileStatuses, setFileStatuses] = useState({});
  const [fileErrors, setFileErrors] = useState({});
  const [extractedData, setExtractedData] = useState({}); // name -> [records]
  const [teachers, setTeachers] = useState([]);
  const [progress, setProgress] = useState(0);
  const [progressMsg, setProgressMsg] = useState("");
  const [config, setConfig] = useState({
    schoolName: "SUNBEAM SCHOOL, LAHARTARA",
    blockName: "",
    period: "",
    generatedBy: "",
  });
  const [finalHTML, setFinalHTML] = useState("");
  const [globalError, setGlobalError] = useState("");
  const [showRaw, setShowRaw] = useState(false);
  const dropRef = useRef();

  const setStatus = (name, status) => setFileStatuses(prev => ({ ...prev, [name]: status }));
  const setError = (name, err) => setFileErrors(prev => ({ ...prev, [name]: err }));

  const onDrop = useCallback((e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files).filter(f =>
      f.name.endsWith(".pdf") || f.name.endsWith(".docx") || f.name.endsWith(".doc") || f.type.startsWith("text/")
    );
    setFiles(prev => {
      const existing = new Set(prev.map(f => f.name));
      return [...prev, ...dropped.filter(f => !existing.has(f.name))];
    });
  }, []);

  const onFileInput = (e) => {
    const selected = Array.from(e.target.files).filter(f =>
      f.name.endsWith(".pdf") || f.name.endsWith(".docx") || f.name.endsWith(".doc") || f.type.startsWith("text/")
    );
    setFiles(prev => {
      const existing = new Set(prev.map(f => f.name));
      return [...prev, ...selected.filter(f => !existing.has(f.name))];
    });
  };

  const removeFile = (name) => setFiles(prev => prev.filter(f => f.name !== name));

  const processFiles = async () => {
    if (files.length === 0) return;
    setStep("processing");
    setGlobalError("");
    setFileStatuses({});
    setFileErrors({});
    const grouped = {};
    let done = 0;

    for (const file of files) {
      setStatus(file.name, "processing");
      setProgressMsg(`Reading: ${file.name}`);
      try {
        const record = await extractFromFile(file);
        const name = (record.teacher_name || "Unknown Teacher").trim();
        if (!grouped[name]) grouped[name] = [];
        grouped[name].push(record);
        setStatus(file.name, "done");
      } catch (err) {
        console.error("Failed:", file.name, err);
        setStatus(file.name, "error");
        setError(file.name, String(err?.message || err));
      }
      done++;
      setProgress(Math.round((done / files.length) * 100));
    }

    setExtractedData(grouped);
    setProgressMsg("");

    if (Object.keys(grouped).length === 0) {
      setGlobalError("No data could be extracted. Ensure files are valid PDFs or DOCXs with readable text and try again.");
      // Stay on processing step so user sees per-file errors
    } else {
      setStep("config");
    }
  };

  const generateReport = async () => {
    if (!config.schoolName || !config.blockName || !config.period || !config.generatedBy) {
      setGlobalError("Please fill in all report details.");
      return;
    }
    setGlobalError("");
    setStep("generating");
    setProgress(0);

    try {
      const teacherNames = Object.keys(extractedData);
      const consolidated = [];
      let done = 0;

      const alreadyAssigned = [];
      for (const name of teacherNames) {
        const records = extractedData[name];
        setProgressMsg(`Analysing ${name} (${records.length} day${records.length > 1 ? "s" : ""})…`);
        try {
          const analysis = await rateTeacher(records, teacherNames, alreadyAssigned);
          alreadyAssigned.push(analysis.rating);
          const avgTT = Math.round(records.reduce((s, r) => s + (r.tt_ratio || 60), 0) / records.length);
          consolidated.push({
            teacher_name: name,
            records,
            analysis,
            avgTT,
            avgST: 100 - avgTT,
          });
        } catch (err) {
          console.error("Rating failed for", name, err);
          // Push with fallback analysis so teacher still appears in report
          consolidated.push({
            teacher_name: name,
            records,
            analysis: {
              rating: 3.5,
              consolidated_strengths: records[0]?.strengths || ["Not specified"],
              consolidated_improvements: records[0]?.improvements || ["Not specified"],
              consolidated_actions: records[0]?.action_points || ["Not specified"],
              aha_moment: records[0]?.aha_moment || "Not specified",
              noteworthy: records[0]?.noteworthy || "Not specified",
              lesson_flow: records[0]?.lesson_flow || "Not specified",
              overall_summary: records[0]?.raw_summary || "Summary not available.",
            },
            avgTT: Math.round(records.reduce((s, r) => s + (r.tt_ratio || 60), 0) / records.length),
            avgST: Math.round(records.reduce((s, r) => s + (r.st_ratio || 40), 0) / records.length),
          });
        }
        done++;
        setProgress(Math.round((done / teacherNames.length) * 80));
      }

      setProgressMsg("Writing executive summary…");
      let execSummary = "";
      try {
        execSummary = await generateExecutiveSummary(consolidated, config.blockName, config.period, config.generatedBy);
      } catch (err) {
        console.error("Executive summary failed", err);
        execSummary = `This consolidated report covers ${consolidated.length} teacher${consolidated.length > 1 ? "s" : ""} for ${config.blockName} during ${config.period}. Overall performance reflects a range of strengths and areas for growth across the block.`;
      }
      setProgress(95);

      setProgressMsg("Rendering HTML report…");
      const html = generateHTML(consolidated, config, execSummary);
      setFinalHTML(html);
      setTeachers(consolidated);
      setProgress(100);
      setStep("done");
    } catch (err) {
      console.error("Report generation failed", err);
      setGlobalError(`Report generation failed: ${err?.message || err}. Please go back and try again.`);
      setStep("config");
    }
  };

  const openInNewTab = () => {
    const win = window.open("", "_blank");
    if (win) {
      win.document.open();
      win.document.write(finalHTML);
      win.document.close();
    } else {
      setShowRaw(true);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(finalHTML).then(() => {
      alert("✅ HTML copied!\n\nNow:\n1. Open Notepad (or any text editor)\n2. Paste (Ctrl+V)\n3. Save As → filename.html\n4. Open in browser");
    }).catch(() => {
      setShowRaw(true);
    });
  };

  const reset = () => {
    setStep("upload"); setFiles([]); setFileStatuses({}); setFileErrors({});
    setExtractedData({}); setTeachers([]); setProgress(0);
    setProgressMsg(""); setFinalHTML(""); setGlobalError("");
  };

  // ── RENDER ──
  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg,#0f172a 0%,#1e3a5f 50%,#1d4ed8 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: "'Segoe UI', Arial, sans-serif" }}>

      <div style={{ width: "100%", maxWidth: 780, background: "white", borderRadius: 20, overflow: "hidden", boxShadow: "0 25px 60px rgba(0,0,0,0.35)" }}>

        {/* Header */}
        <div style={{ background: "linear-gradient(135deg,#1e3a5f,#2563eb)", color: "white", padding: "28px 36px" }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: 0.3 }}>📊 Teacher Report Builder</div>
            <div style={{ fontSize: 13, opacity: 0.75, marginTop: 3 }}>AI-powered consolidated report generator</div>
            <div style={{ fontSize: 11, opacity: 0.5, marginTop: 2, letterSpacing: 0.5 }}>Developed by Devnil Chatterjee</div>
          </div>
          {/* Step indicator */}
          <div style={{ display: "flex", gap: 8, marginTop: 20, alignItems: "center" }}>
            {[["upload","1","Upload Files"],["processing","2","Extract"],["config","3","Configure"],["generating","4","Analyse"],["done","5","Download"]].map(([s, n, label], i, arr) => {
              const idx = STEPS.indexOf(step);
              const me = STEPS.indexOf(s);
              const active = me === idx;
              const past = me < idx;
              return (
                <div key={s} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <div style={{ width: 26, height: 26, borderRadius: "50%", background: past ? "#22c55e" : active ? "white" : "rgba(255,255,255,0.2)", color: past ? "white" : active ? "#1e3a5f" : "rgba(255,255,255,0.5)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700 }}>{past ? "✓" : n}</div>
                    <span style={{ fontSize: 12, opacity: active ? 1 : 0.55, fontWeight: active ? 700 : 400 }}>{label}</span>
                  </div>
                  {i < arr.length - 1 && <div style={{ width: 20, height: 1, background: "rgba(255,255,255,0.2)" }} />}
                </div>
              );
            })}
          </div>
        </div>

        <div style={{ padding: "32px 36px" }}>

          {/* ── STEP: UPLOAD ── */}
          {step === "upload" && (
            <div>
              <h2 style={{ margin: "0 0 6px", fontSize: 20, color: "#1e3a5f" }}>Upload Teacher Reports</h2>
              <p style={{ margin: "0 0 20px", fontSize: 14, color: "#6b7280" }}>Upload PDF or DOCX files — one or multiple days per teacher, any format. Files from the same teacher are automatically grouped.</p>

              <div
                ref={dropRef}
                onDragOver={e => e.preventDefault()}
                onDrop={onDrop}
                onClick={() => document.getElementById("fileInput").click()}
                style={{ border: "2px dashed #93c5fd", borderRadius: 12, padding: "36px 24px", textAlign: "center", cursor: "pointer", background: "#f0f7ff", marginBottom: 20, transition: "background 0.2s" }}
                onMouseEnter={e => e.currentTarget.style.background = "#dbeafe"}
                onMouseLeave={e => e.currentTarget.style.background = "#f0f7ff"}
              >
                <div style={{ fontSize: 40, marginBottom: 10 }}>📁</div>
                <div style={{ fontSize: 15, fontWeight: 700, color: "#1e3a5f", marginBottom: 4 }}>Drag & drop files here</div>
                <div style={{ fontSize: 13, color: "#6b7280" }}>or click to browse — PDF, DOCX supported</div>
                <input id="fileInput" type="file" multiple accept=".pdf,.docx,.doc,.txt" style={{ display: "none" }} onChange={onFileInput} />
              </div>

              {files.length > 0 && (
                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#374151", marginBottom: 8 }}>{files.length} file{files.length > 1 ? "s" : ""} selected</div>
                  {files.map(f => (
                    <div key={f.name} style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 12px", background: "#f8fafc", borderRadius: 8, border: "1px solid #e2e8f0", marginBottom: 6 }}>
                      <span style={{ fontSize: 16 }}>{f.name.endsWith(".pdf") ? "📄" : "📝"}</span>
                      <span style={{ flex: 1, fontSize: 13, color: "#1e3a5f", fontWeight: 500 }}>{f.name}</span>
                      <span style={{ fontSize: 11, color: "#9ca3af" }}>{(f.size / 1024).toFixed(0)} KB</span>
                      <button onClick={() => removeFile(f.name)} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 16, padding: 2 }}>✕</button>
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={processFiles}
                disabled={files.length === 0}
                style={{ width: "100%", padding: "13px", background: files.length > 0 ? "linear-gradient(135deg,#1e3a5f,#2563eb)" : "#e2e8f0", color: files.length > 0 ? "white" : "#9ca3af", border: "none", borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: files.length > 0 ? "pointer" : "not-allowed" }}
              >
                Extract Data from Files →
              </button>
            </div>
          )}

          {/* ── STEP: PROCESSING ── */}
          {step === "processing" && (
            <div>
              <h2 style={{ margin: "0 0 6px", fontSize: 20, color: "#1e3a5f" }}>
                {progressMsg ? "Extracting Data…" : "Extraction Complete"}
              </h2>
              <p style={{ margin: "0 0 20px", fontSize: 14, color: "#6b7280" }}>{progressMsg || "See results below."}</p>
              <ProgressBar pct={progress} />
              <div style={{ textAlign: "right", fontSize: 12, color: "#6b7280", marginTop: 6, marginBottom: 20 }}>{progress}%</div>
              {files.map(f => (
                <FileCard key={f.name} file={f} status={fileStatuses[f.name] || "pending"} error={fileErrors[f.name]} />
              ))}
              {globalError && (
                <div style={{ marginTop: 16, padding: "12px 16px", background: "#fef2f2", border: "1px solid #fca5a5", borderRadius: 8, color: "#991b1b", fontSize: 13 }}>
                  ⚠️ {globalError}
                </div>
              )}
              {!progressMsg && (
                <button onClick={reset} style={{ marginTop: 16, width: "100%", padding: "11px", background: "#f1f5f9", color: "#374151", border: "1px solid #e2e8f0", borderRadius: 10, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
                  ← Go Back and Try Again
                </button>
              )}
            </div>
          )}

          {/* ── STEP: CONFIG ── */}
          {step === "config" && (
            <div>
              <h2 style={{ margin: "0 0 6px", fontSize: 20, color: "#1e3a5f" }}>Configure Report</h2>
              <p style={{ margin: "0 0 20px", fontSize: 14, color: "#6b7280" }}>
                Extracted data from <strong>{Object.keys(extractedData).length} teacher{Object.keys(extractedData).length > 1 ? "s" : ""}</strong>
                {" "}across <strong>{files.length} file{files.length > 1 ? "s" : ""}</strong>. Fill in report details below.
              </p>

              {Object.keys(extractedData).map(name => (
                <div key={name} style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 12px", background: "#f0fdf4", borderRadius: 8, border: "1px solid #86efac", marginBottom: 6 }}>
                  <span style={{ fontSize: 15 }}>👤</span>
                  <span style={{ flex: 1, fontSize: 13, color: "#166534", fontWeight: 600 }}>{name}</span>
                  <span style={{ fontSize: 12, color: "#6b7280" }}>{extractedData[name].length} day{extractedData[name].length > 1 ? "s" : ""}</span>
                </div>
              ))}

              <div style={{ marginTop: 20, display: "grid", gap: 14 }}>
                {[
                  ["schoolName", "School Name", "e.g. SUNBEAM SCHOOL, LAHARTARA"],
                  ["blockName", "Block Name", "e.g. XI-XII"],
                  ["period", "Period", "e.g. 27 April 2026 — 02 May 2026"],
                  ["generatedBy", "Generated By", "Your name"],
                ].map(([key, label, placeholder]) => (
                  <div key={key}>
                    <label style={{ display: "block", fontSize: 13, fontWeight: 700, color: "#374151", marginBottom: 5 }}>{label}</label>
                    <input
                      value={config[key]}
                      onChange={e => setConfig(prev => ({ ...prev, [key]: e.target.value }))}
                      placeholder={placeholder}
                      style={{ width: "100%", padding: "10px 14px", border: "1px solid #d1d9e0", borderRadius: 8, fontSize: 14, outline: "none" }}
                    />
                  </div>
                ))}
              </div>

              {globalError && <div style={{ marginTop: 14, padding: "10px 14px", background: "#fef2f2", border: "1px solid #fca5a5", borderRadius: 8, color: "#991b1b", fontSize: 13 }}>{globalError}</div>}

              <button
                onClick={generateReport}
                style={{ marginTop: 20, width: "100%", padding: "13px", background: "linear-gradient(135deg,#1e3a5f,#2563eb)", color: "white", border: "none", borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: "pointer" }}
              >
                Generate Consolidated Report →
              </button>
            </div>
          )}

          {/* ── STEP: GENERATING ── */}
          {step === "generating" && (
            <div>
              <h2 style={{ margin: "0 0 6px", fontSize: 20, color: "#1e3a5f" }}>Generating Report…</h2>
              <p style={{ margin: "0 0 20px", fontSize: 14, color: "#6b7280" }}>{progressMsg}</p>
              <ProgressBar pct={progress} />
              <div style={{ textAlign: "right", fontSize: 12, color: "#6b7280", marginTop: 6 }}>{progress}%</div>
              <div style={{ marginTop: 24, padding: 20, background: "#f0f7ff", borderRadius: 12, border: "1px solid #bfdbfe", fontSize: 14, color: "#374151", lineHeight: 1.7 }}>
                <strong>🤖 What's happening:</strong><br />
                Claude is reading each teacher's reports, synthesising strengths and growth areas across the week, assigning a holistic rating, and then writing the executive summary for the whole block.
              </div>
            </div>
          )}

          {/* ── STEP: DONE ── */}
          {step === "done" && (
            <div>
              <div style={{ textAlign: "center", marginBottom: 20 }}>
                <div style={{ fontSize: 52 }}>🎉</div>
                <h2 style={{ margin: "8px 0 4px", fontSize: 22, color: "#1e3a5f" }}>Report Ready!</h2>
                <p style={{ margin: 0, fontSize: 14, color: "#6b7280" }}>
                  {teachers.length} teachers analysed · Block {config.blockName} · {config.period}
                </p>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 20 }}>
                {[
                  ["👩‍🏫", "Teachers", teachers.length],
                  ["⭐", "Avg Rating", (teachers.reduce((s, t) => s + t.analysis.rating, 0) / teachers.length).toFixed(1) + "/5"],
                  ["📄", "Files", files.length],
                ].map(([icon, label, val]) => (
                  <div key={label} style={{ background: "#f0f7ff", borderRadius: 12, padding: "16px 12px", textAlign: "center", border: "1px solid #bfdbfe" }}>
                    <div style={{ fontSize: 24 }}>{icon}</div>
                    <div style={{ fontSize: 20, fontWeight: 800, color: "#1e3a5f", marginTop: 4 }}>{val}</div>
                    <div style={{ fontSize: 12, color: "#6b7280" }}>{label}</div>
                  </div>
                ))}
              </div>

              {/* Step-by-step save instructions */}
              <div style={{ background: "#f0fdf4", border: "1px solid #86efac", borderRadius: 10, padding: "14px 18px", marginBottom: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#166534", marginBottom: 8 }}>💾 How to save your report:</div>
                <div style={{ fontSize: 13, color: "#374151", lineHeight: 2 }}>
                  <b>Option A (easiest):</b> Click <b>"Open in New Tab"</b> → press <b>Ctrl+S</b> (or Cmd+S on Mac) → save as <b>.html</b><br/>
                  <b>Option B:</b> Click <b>"Copy HTML"</b> → open Notepad → Paste → Save As <b>report.html</b>
                </div>
              </div>

              <button
                onClick={openInNewTab}
                style={{ width: "100%", padding: "14px", background: "linear-gradient(135deg,#1e3a5f,#2563eb)", color: "white", border: "none", borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: "pointer", marginBottom: 10 }}
              >
                🌐 Open in New Tab → then Ctrl+S to Save
              </button>

              <button
                onClick={copyToClipboard}
                style={{ width: "100%", padding: "13px", background: "linear-gradient(135deg,#166534,#16a34a)", color: "white", border: "none", borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: "pointer", marginBottom: 10 }}
              >
                📋 Copy HTML to Clipboard
              </button>

              <button
                onClick={() => setShowRaw(!showRaw)}
                style={{ width: "100%", padding: "11px", background: "#fefce8", color: "#854d0e", border: "1px solid #fde047", borderRadius: 10, fontSize: 14, fontWeight: 600, cursor: "pointer", marginBottom: 10 }}
              >
                {showRaw ? "▲ Hide Raw HTML" : "▼ Show Raw HTML (select all → copy → paste to file)"}
              </button>

              {showRaw && (
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 6 }}>Select all text below (Ctrl+A inside the box), copy, paste into a .html file:</div>
                  <textarea
                    readOnly
                    value={finalHTML}
                    onClick={e => e.target.select()}
                    style={{ width: "100%", height: 200, fontSize: 11, fontFamily: "monospace", border: "1px solid #d1d9e0", borderRadius: 8, padding: 10, resize: "vertical", color: "#374151", background: "#f8fafc" }}
                  />
                </div>
              )}

              <button
                onClick={reset}
                style={{ width: "100%", padding: "11px", background: "#f1f5f9", color: "#374151", border: "1px solid #e2e8f0", borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: "pointer" }}
              >
                ↺ Start New Report
              </button>
            </div>
          )}

        </div>
      </div>
      </div>
    </div>
  );
}
